-- ============================================================================
--  SiGeRU 2026 - Sistema de Gestion de Residuos Urbanos
--  Archivo: schema.sql
--  Que es: DDL (Data Definition Language) de la base de datos.
--          Aca se CREAN la base de datos y todas las tablas.
--  Motor : MySQL 8
--  Entrega: Entrega 1 (primera version del modelo fisico)
-- ============================================================================
--
--  Como leerlo:
--   - Cada CREATE TABLE define una entidad del sistema.
--   - Las FOREIGN KEY relacionan tablas entre si.
--   - Se usa InnoDB porque soporta claves foraneas y transacciones.
--   - Se usa utf8mb4 para soportar tildes, enie y emojis.
-- ============================================================================

-- 1) Creamos la base de datos solo si no existe, y la seleccionamos.
CREATE DATABASE IF NOT EXISTS sigeru
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sigeru;

-- ----------------------------------------------------------------------------
-- TABLA: rol
-- Que guarda: los tipos de usuario del sistema.
-- Roles segun la consigna: Administrador, Cuadrilla, Operario, Vecino.
-- ----------------------------------------------------------------------------
CREATE TABLE rol (
    id_rol      INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(50)  NOT NULL UNIQUE,   -- ej: 'Administrador'
    descripcion VARCHAR(200) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- TABLA: usuario
-- Que guarda: las personas que usan el sistema (ya aprobadas).
-- Relacion: cada usuario tiene un rol (rol.id_rol).
-- Nota: la contrasena se guarda HASHEADA, nunca en texto plano.
-- ----------------------------------------------------------------------------
CREATE TABLE usuario (
    id_usuario     INT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(80)  NOT NULL,
    apellido       VARCHAR(80)  NOT NULL,
    email          VARCHAR(120) NOT NULL UNIQUE,    -- sirve para el login
    password_hash  VARCHAR(255) NOT NULL,           -- hash de la contrasena
    telefono       VARCHAR(30)  NULL,
    direccion      VARCHAR(200) NULL,
    id_rol         INT          NOT NULL,
    estado         ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
    fecha_registro DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_usuario_rol
        FOREIGN KEY (id_rol) REFERENCES rol(id_rol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- TABLA: solicitud_registro
-- Que guarda: pedidos de alta que todavia NO fueron aprobados por un admin.
-- Cuando el admin aprueba, se crea un registro en 'usuario'.
-- ----------------------------------------------------------------------------
CREATE TABLE solicitud_registro (
    id_solicitud    INT AUTO_INCREMENT PRIMARY KEY,
    nombre          VARCHAR(80)  NOT NULL,
    apellido        VARCHAR(80)  NOT NULL,
    email           VARCHAR(120) NOT NULL,
    telefono        VARCHAR(30)  NULL,
    direccion       VARCHAR(200) NULL,
    estado          ENUM('pendiente','aprobada','rechazada') NOT NULL DEFAULT 'pendiente',
    fecha_solicitud DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- TABLA: tipo_residuo
-- Que guarda: las categorias de residuos (organico, plastico, vidrio, etc).
-- ----------------------------------------------------------------------------
CREATE TABLE tipo_residuo (
    id_tipo_residuo INT AUTO_INCREMENT PRIMARY KEY,
    nombre          VARCHAR(60)  NOT NULL UNIQUE,
    descripcion     VARCHAR(200) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- TABLA: centro_acopio
-- Que guarda: lugares donde se concentran los residuos recolectados.
-- Guarda latitud/longitud para poder mostrarlos en un mapa mas adelante.
-- ----------------------------------------------------------------------------
CREATE TABLE centro_acopio (
    id_centro  INT AUTO_INCREMENT PRIMARY KEY,
    nombre     VARCHAR(120) NOT NULL,
    direccion  VARCHAR(200) NULL,
    latitud    DECIMAL(10,7) NULL,
    longitud   DECIMAL(10,7) NULL,
    capacidad  INT NULL,                 -- capacidad estimada (en kg o m3)
    estado     ENUM('activo','inactivo') NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- TABLA: contenedor
-- Que guarda: los contenedores de residuos repartidos en la ciudad.
-- Relaciones:
--   - tipo_residuo: que tipo de residuo acepta el contenedor.
--   - centro_acopio: a que centro se lleva lo recolectado (puede ser NULL).
-- ----------------------------------------------------------------------------
CREATE TABLE contenedor (
    id_contenedor   INT AUTO_INCREMENT PRIMARY KEY,
    codigo          VARCHAR(30)  NOT NULL UNIQUE,   -- codigo identificador fisico
    direccion       VARCHAR(200) NOT NULL,
    latitud         DECIMAL(10,7) NULL,
    longitud        DECIMAL(10,7) NULL,
    capacidad       INT NULL,                        -- capacidad en litros
    estado          ENUM('disponible','lleno','mantenimiento','retirado')
                        NOT NULL DEFAULT 'disponible',
    id_tipo_residuo INT NULL,
    id_centro       INT NULL,
    CONSTRAINT fk_contenedor_tipo
        FOREIGN KEY (id_tipo_residuo) REFERENCES tipo_residuo(id_tipo_residuo),
    CONSTRAINT fk_contenedor_centro
        FOREIGN KEY (id_centro) REFERENCES centro_acopio(id_centro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- TABLA: camion
-- Que guarda: los camiones recolectores de la flota.
-- ----------------------------------------------------------------------------
CREATE TABLE camion (
    id_camion  INT AUTO_INCREMENT PRIMARY KEY,
    matricula  VARCHAR(20)  NOT NULL UNIQUE,
    marca      VARCHAR(60)  NULL,
    modelo     VARCHAR(60)  NULL,
    capacidad  INT NULL,                  -- capacidad de carga en kg
    estado     ENUM('operativo','en_ruta','mantenimiento','fuera_servicio')
                   NOT NULL DEFAULT 'operativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Fin del schema de la Entrega 1.
-- En Entregas 2 y 3 se agregaran: rutas, asignacion de cuadrillas,
-- incidencias, mantenimiento y repuestos.
-- ============================================================================
