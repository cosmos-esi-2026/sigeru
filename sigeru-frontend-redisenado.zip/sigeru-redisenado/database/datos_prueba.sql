-- ============================================================================
--  SiGeRU 2026 - Datos de prueba (seed)
--  Archivo: datos_prueba.sql
--  Que es: registros de ejemplo para poder probar y navegar el sistema.
--          Se ejecuta DESPUES de schema.sql.
--  Entrega: Entrega 1 (datos minimos para demostrar listados)
-- ============================================================================
--
--  Nota sobre las contrasenas:
--   El password_hash de abajo corresponde a la contrasena "123456".
--   Fue generado con password_hash('123456', PASSWORD_DEFAULT) en PHP 8.
--   En produccion cada usuario tendria su propia contrasena segura.
-- ============================================================================

USE sigeru;

-- Roles del sistema (segun la consigna)
INSERT INTO rol (nombre, descripcion) VALUES
('Administrador', 'Acceso total al sistema y al backoffice'),
('Cuadrilla',     'Equipo de recoleccion en la calle'),
('Operario',      'Operario de centros de acopio y mantenimiento'),
('Vecino',        'Vecino que reporta incidencias y usa el sistema');

-- Tipos de residuo
INSERT INTO tipo_residuo (nombre, descripcion) VALUES
('Organico', 'Restos de comida y residuos biodegradables'),
('Plastico', 'Botellas y envases plasticos'),
('Vidrio',   'Botellas y envases de vidrio'),
('Papel',    'Papel y carton'),
('Metal',    'Latas y residuos metalicos');

-- Centros de acopio
INSERT INTO centro_acopio (nombre, direccion, latitud, longitud, capacidad) VALUES
('Centro Norte', 'Av. Italia 1234',     -34.8721000, -56.1500000, 10000),
('Centro Sur',   'Calle Comercio 567',  -34.9050000, -56.1900000, 8000);

-- Usuarios (contrasena de todos: 123456)
INSERT INTO usuario (nombre, apellido, email, password_hash, telefono, direccion, id_rol) VALUES
('Ana',   'Perez',    'admin@sigeru.uy',    '$2y$10$wH8QqQnU0bqI7m6Yp3i4MeQ2sJ0r1uOeXcVbN9aZ8dF5gH2kL3mC', '099111222', 'Oficina central', 1),
('Luis',  'Gomez',    'cuadrilla@sigeru.uy','$2y$10$wH8QqQnU0bqI7m6Yp3i4MeQ2sJ0r1uOeXcVbN9aZ8dF5gH2kL3mC', '099333444', 'Barrio Centro',  2),
('Marta', 'Rodriguez','vecino@sigeru.uy',   '$2y$10$wH8QqQnU0bqI7m6Yp3i4MeQ2sJ0r1uOeXcVbN9aZ8dF5gH2kL3mC', '099555666', 'Calle 18 N123',  4);

-- Contenedores
INSERT INTO contenedor (codigo, direccion, latitud, longitud, capacidad, estado, id_tipo_residuo, id_centro) VALUES
('CNT-001', 'Av. Italia esq. Propios', -34.8730000, -56.1480000, 1100, 'disponible', 1, 1),
('CNT-002', 'Plaza Independencia',      -34.9070000, -56.1990000, 1100, 'lleno',      2, 2),
('CNT-003', 'Bvar. Artigas 2200',       -34.8950000, -56.1660000, 800,  'disponible', 3, 1);

-- Camiones
INSERT INTO camion (matricula, marca, modelo, capacidad, estado) VALUES
('SAB-1234', 'Mercedes-Benz', 'Atego',   5000, 'operativo'),
('SBC-5678', 'Iveco',         'Tector',  6000, 'mantenimiento'),
('SCD-9012', 'Volkswagen',    'Worker',  4500, 'en_ruta');

-- Solicitud de registro pendiente (para probar el flujo de aprobacion)
INSERT INTO solicitud_registro (nombre, apellido, email, telefono, direccion) VALUES
('Pedro', 'Sosa', 'pedro.sosa@mail.com', '099777888', 'Calle Falsa 123');