/* ==========================================================================
   SiGeRU 2026 - Frontend de usuarios
   Archivo: js/api.js
   Que es: configuracion central y funciones para hablar con las APIs.
           Lo usan todas las demas paginas (usuarios, contenedores, camiones).

   Asi, si cambia una direccion de API, se cambia en UN solo lugar.
   ========================================================================== */

// --- URLs base de cada API (coinciden con los puertos del docker-compose) ---
const API = {
  usuarios:    "http://localhost:8081",
  gestion:     "http://localhost:8082",
  recoleccion: "http://localhost:8083",
};

// --- Funcion para pedir datos (GET) ---
// Devuelve el JSON de la API o lanza un error si algo falla.
async function apiGet(url) {
  const respuesta = await fetch(url);
  if (!respuesta.ok) {
    throw new Error("Error al obtener datos (" + respuesta.status + ")");
  }
  return await respuesta.json();
}

// --- Funcion para enviar datos (POST) ---
async function apiPost(url, datos) {
  const respuesta = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(datos),
  });
  const resultado = await respuesta.json();
  // Devolvemos tambien si fue exitoso para que la pagina decida que mostrar.
  return { ok: respuesta.ok, resultado };
}

// --- Sesion (muy simple para Entrega 1) ---
// Guardamos el usuario logueado en localStorage del navegador.
const Sesion = {
  guardar(usuario) {
    localStorage.setItem("sigeru_usuario", JSON.stringify(usuario));
  },
  obtener() {
    const dato = localStorage.getItem("sigeru_usuario");
    return dato ? JSON.parse(dato) : null;
  },
  cerrar() {
    localStorage.removeItem("sigeru_usuario");
  },
  // Si no hay sesion, manda al login. Se llama al entrar a paginas privadas.
  exigir() {
    if (!this.obtener()) {
      window.location.href = "login.html";
    }
  },
};

// --- Cableado automatico del boton "Cerrar sesion" ---
// Si la pagina tiene un elemento con id="btn-salir", le conectamos el cierre
// de sesion. Asi no repetimos este codigo en cada pagina.
document.addEventListener("DOMContentLoaded", function () {
  const botonSalir = document.getElementById("btn-salir");
  if (botonSalir) {
    botonSalir.addEventListener("click", function (e) {
      e.preventDefault();
      Sesion.cerrar();
      window.location.href = "login.html";
    });
  }
});