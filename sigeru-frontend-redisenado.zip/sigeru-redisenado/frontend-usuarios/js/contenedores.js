/* ==========================================================================
   SiGeRU 2026 - Frontend de usuarios
   Archivo: js/contenedores.js
   Que hace: lista los contenedores (API de gestion) y permite dar de alta.
   ========================================================================== */

Sesion.exigir();

const cuerpoTabla = document.getElementById("cuerpo-tabla");
const formContenedor = document.getElementById("form-contenedor");
const mensaje = document.getElementById("mensaje");

// Elige el color de la etiqueta de estado segun el valor.
function colorEstado(estado) {
  if (estado === "disponible") return "verde";
  if (estado === "lleno") return "rojo";
  if (estado === "mantenimiento") return "naranja";
  return "gris"; // retirado u otros
}

async function cargarContenedores() {
  cuerpoTabla.innerHTML = "<tr><td colspan='6'>Cargando...</td></tr>";
  try {
    const datos = await apiGet(API.gestion + "/contenedores");
    dibujarTabla(datos.datos);
  } catch (e) {
    cuerpoTabla.innerHTML =
      "<tr><td colspan='6'>No se pudo conectar con la API. Levanta Docker.</td></tr>";
  }
}

function dibujarTabla(contenedores) {
  if (!contenedores || contenedores.length === 0) {
    cuerpoTabla.innerHTML = "<tr><td colspan='6'>No hay contenedores.</td></tr>";
    return;
  }

  cuerpoTabla.innerHTML = "";
  contenedores.forEach(function (c) {
    const fila = `
      <tr>
        <td>${c.id_contenedor}</td>
        <td>${c.codigo}</td>
        <td>${c.direccion}</td>
        <td>${c.capacidad ?? "-"}</td>
        <td>${c.tipo_residuo ?? "-"}</td>
        <td><span class="estado ${colorEstado(c.estado)}">${c.estado}</span></td>
      </tr>`;
    cuerpoTabla.innerHTML += fila;
  });
}

formContenedor.addEventListener("submit", async function (evento) {
  evento.preventDefault();

  const datos = {
    codigo:       formContenedor.codigo.value,
    direccion:    formContenedor.direccion.value,
    capacidad:    formContenedor.capacidad.value,
    tipo_residuo: formContenedor.tipo_residuo.value,
    estado:       formContenedor.estado.value,
  };

  try {
    const { ok, resultado } = await apiPost(API.gestion + "/contenedores", datos);
    if (ok) {
      mostrar("Contenedor creado correctamente.", "ok");
      formContenedor.reset();
      cargarContenedores();
    } else {
      mostrar(resultado.mensaje || "No se pudo crear el contenedor.", "error");
    }
  } catch (e) {
    mostrar("No se pudo conectar con la API.", "error");
  }
});

function mostrar(texto, tipo) {
  mensaje.textContent = texto;
  mensaje.className = "mensaje " + tipo;
}

document.getElementById("btn-recargar").addEventListener("click", cargarContenedores);
cargarContenedores();