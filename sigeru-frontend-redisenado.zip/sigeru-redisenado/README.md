# SiGeRU 2026 — Sistema de Gestión de Residuos Urbanos

Proyecto de Programación Full Stack — UTU/ESI 2026.

Tecnologías: **HTML5, CSS, JavaScript, PHP 8, MySQL 8 y Docker**. Arquitectura **MVC** en las APIs. Sin frameworks (no React, Vue, Angular, Next ni Tailwind).

---

## ¿Qué incluye esta Entrega 1?

- ✅ Landing page pública (`landing/`)
- ✅ Registro y login navegables (`frontend-usuarios/`)
- ✅ Listados y formularios de **usuarios, contenedores y camiones**
- ✅ APIs REST básicas (usuarios, gestión, recolección) con endpoints GET y POST
- ✅ Backoffice básico de administración (`backoffice/`)
- ✅ Modelo físico de base de datos + DDL + dump de estructura (`database/`)
- ✅ Docker para levantar todo (`docker/`)

> **Nota Entrega 1:** las APIs aún **no persisten en MySQL**: devuelven datos en
> memoria (arrays PHP). El código ya está preparado para conectar MySQL en la
> Entrega 2 (ver `config/database.php` en cada API y los comentarios `Entrega 2:`).

---

## Estructura del proyecto

```
sigeru/
├── landing/             Página pública (HTML/CSS/JS)
├── frontend-usuarios/   App de usuarios: login, registro, listados, formularios
├── backoffice/          Panel de administración
├── api-usuarios/        API REST de usuarios       (PHP, MVC)
├── api-gestion/         API REST de contenedores   (PHP, MVC)
├── api-recoleccion/     API REST de camiones       (PHP, MVC)
├── database/            schema.sql, dump y datos de prueba
└── docker/              docker-compose.yml + Dockerfile
```

Cada API sigue el patrón **MVC**:
- `index.php` → router (decide qué hacer según la URL).
- `controllers/` → reciben la petición y responden.
- `models/` → los datos (hoy en memoria, mañana MySQL).
- `core/Response.php` → ayuda a responder en JSON.
- `config/database.php` → conexión a MySQL (lista para Entrega 2).

---

## Diseño del frontend

Todo el CSS es propio, sin frameworks. El sistema visual se llama
**"banda de clasificación"**: la franja de cinco colores que aparece bajo el
encabezado, al pie de las tarjetas de login y en el footer representa los tipos
de residuo (orgánico, plástico, vidrio, papel, metal). Esos mismos colores se
reutilizan como etiquetas de tipo y como acento de cada tarjeta, así que no son
decoración: informan.

- **Colores y tipografías** se definen como variables CSS en el bloque `:root`
  de cada hoja de estilos. Cambiando ahí un valor cambia toda la página.
- **Tipografías:** Space Grotesk (títulos), IBM Plex Sans (texto) e
  IBM Plex Mono (códigos, matrículas e IDs). Se cargan desde Google Fonts y,
  si no hay internet, el navegador usa las del sistema.
- **Landing y frontend de usuarios** usan fondo claro; el **backoffice** usa
  tema oscuro a propósito, para que se note de un vistazo que es la
  herramienta interna.
- Responsive hasta 390 px, foco visible con teclado y respeto por
  `prefers-reduced-motion`.

| Parte | Hoja de estilos |
|---|---|
| Landing | `landing/css/styles.css` |
| Frontend de usuarios | `frontend-usuarios/css/styles.css` |
| Backoffice | `backoffice/css/styles.css` |

---

## Cómo levantar el proyecto con Docker

Requisito: tener **Docker Desktop** instalado.

```bash
cd sigeru/docker
docker compose up --build
```

Cuando termine de levantar, abrir en el navegador:

| Parte | Dirección |
|---|---|
| Landing | http://localhost:8080/landing/index.html |
| Frontend de usuarios | http://localhost:8080/frontend-usuarios/login.html |
| Backoffice | http://localhost:8080/backoffice/index.html |
| API usuarios | http://localhost:8081 |
| API gestión | http://localhost:8082 |
| API recolección | http://localhost:8083 |

Para apagar todo: `Ctrl + C` y luego `docker compose down`.

---

## Usuarios de prueba

Todos tienen la contraseña **`123456`**.

| Email | Rol |
|---|---|
| admin@sigeru.uy | Administrador |
| cuadrilla@sigeru.uy | Cuadrilla |
| vecino@sigeru.uy | Vecino |

El backoffice solo deja entrar al usuario con rol **Administrador**.

---

## Probar las APIs directamente

```
GET  http://localhost:8081/usuarios
GET  http://localhost:8082/contenedores
GET  http://localhost:8083/camiones
```

---

## Base de datos

- `database/schema.sql` → crea la base y todas las tablas (DDL comentado).
- `database/dump_estructura.sql` → solo la estructura (sin datos).
- `database/datos_prueba.sql` → datos de ejemplo.

Al levantar Docker, MySQL ejecuta `schema.sql` y `datos_prueba.sql`
automáticamente la primera vez.

---

## Próximas entregas (resumen)

- **Entrega 2:** persistencia real con MySQL, CRUD completo, seguridad por roles, tests, datos de prueba.
- **Entrega 3:** API de recolección completa, incidencias, mapa interactivo, reportes y panel con estadísticas.