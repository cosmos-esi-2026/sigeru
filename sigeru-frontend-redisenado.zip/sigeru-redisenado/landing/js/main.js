/* ==========================================================================
   SiGeRU 2026 - JavaScript de la Landing page
   Archivo: landing/js/main.js

   Que hace:
   - Toma el formulario de "Solicitar registro".
   - Cuando el usuario lo envia, NO recarga la pagina.
   - Envia los datos a la API de usuarios (endpoint de solicitudes).

   IMPORTANTE (Entrega 1):
   - La API todavia NO guarda en base de datos real: responde con datos
     simulados en memoria. El codigo del frontend ya queda listo para
     cuando la persistencia este disponible (no hay que cambiarlo).
   ========================================================================== */

// URL base de la API de usuarios.
// Con Docker, la API queda accesible en http://localhost:8081
const API_USUARIOS = "http://localhost:8081";

// Buscamos los elementos del HTML con los que vamos a trabajar.
const formulario = document.getElementById("form-registro");
const mensaje = document.getElementById("mensaje-registro");

// Escuchamos el evento "submit" (envio) del formulario.
formulario.addEventListener("submit", async function (evento) {
  // Evita que el navegador recargue la pagina al enviar.
  evento.preventDefault();

  // Armamos un objeto con los datos del formulario.
  const datos = {
    nombre:    formulario.nombre.value,
    apellido:  formulario.apellido.value,
    email:     formulario.email.value,
    telefono:  formulario.telefono.value,
    direccion: formulario.direccion.value,
  };

  try {
    // Enviamos los datos a la API con fetch (peticion POST).
    const respuesta = await fetch(API_USUARIOS + "/solicitudes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(datos),
    });

    const resultado = await respuesta.json();

    if (respuesta.ok) {
      mostrarMensaje("Solicitud enviada correctamente. Te contactaremos.", "ok");
      formulario.reset(); // limpia el formulario
    } else {
      mostrarMensaje(resultado.mensaje || "No se pudo enviar la solicitud.", "error");
    }
  } catch (error) {
    // Si la API no esta levantada todavia, avisamos de forma amable.
    mostrarMensaje(
      "No se pudo conectar con el servidor. Levanta la API con Docker e intenta de nuevo.",
      "error"
    );
  }
});

// Funcion auxiliar para mostrar mensajes con estilo (ok / error).
function mostrarMensaje(texto, tipo) {
  mensaje.textContent = texto;
  mensaje.className = "mensaje " + tipo;
}