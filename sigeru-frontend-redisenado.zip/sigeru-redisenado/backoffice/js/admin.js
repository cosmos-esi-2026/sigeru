/* ==========================================================================
   SiGeRU 2026 - Backoffice
   Archivo: js/admin.js
   Que es: configuracion y sesion del panel de administracion.
           Lo usan index.html (login) y dashboard.html (resumen).
   ========================================================================== */

// URLs de las APIs (mismos puertos que el frontend de usuarios).
const API_USUARIOS    = "http://localhost:8081";
const API_GESTION     = "http://localhost:8082";
const API_RECOLECCION = "http://localhost:8083";

// Sesion del administrador (separada de la del frontend de usuarios).
const AdminSesion = {
  guardar(usuario) {
    localStorage.setItem("sigeru_admin", JSON.stringify(usuario));
  },
  obtener() {
    const dato = localStorage.getItem("sigeru_admin");
    return dato ? JSON.parse(dato) : null;
  },
  cerrar() {
    localStorage.removeItem("sigeru_admin");
  },
  // Exige sesion de admin; si no hay, vuelve al login del backoffice.
  exigir() {
    if (!this.obtener()) {
      window.location.href = "index.html";
    }
  },
};

// Cablea el boton "Cerrar sesion" si existe en la pagina.
document.addEventListener("DOMContentLoaded", function () {
  const botonSalir = document.getElementById("btn-salir");
  if (botonSalir) {
    botonSalir.addEventListener("click", function (e) {
      e.preventDefault();
      AdminSesion.cerrar();
      window.location.href = "index.html";
    });
  }
});