<?php
// ============================================================================
//  SiGeRU 2026 - API de recoleccion
//  Archivo: models/Camion.php  (modelo)
//  ENTREGA 1: datos en memoria. En Entrega 2 se reemplaza por consultas SQL
//  a la tabla 'camion'.
// ============================================================================

class Camion
{
    private static array $camiones = [
        [
            "id_camion" => 1, "matricula" => "SAB-1234",
            "marca" => "Mercedes-Benz", "modelo" => "Atego",
            "capacidad" => 5000, "estado" => "operativo"
        ],
        [
            "id_camion" => 2, "matricula" => "SBC-5678",
            "marca" => "Iveco", "modelo" => "Tector",
            "capacidad" => 6000, "estado" => "mantenimiento"
        ],
        [
            "id_camion" => 3, "matricula" => "SCD-9012",
            "marca" => "Volkswagen", "modelo" => "Worker",
            "capacidad" => 4500, "estado" => "en_ruta"
        ],
    ];

    // Entrega 2: SELECT * FROM camion;
    public static function listar(): array
    {
        return self::$camiones;
    }

    // Entrega 2: SELECT * FROM camion WHERE id_camion = ?;
    public static function obtener(int $id): ?array
    {
        foreach (self::$camiones as $c) {
            if ($c["id_camion"] === $id) {
                return $c;
            }
        }
        return null;
    }

    // Entrega 2: INSERT INTO camion (...) VALUES (...);
    public static function crear(array $datos): array
    {
        $nuevoId = count(self::$camiones) + 1;
        return [
            "id_camion" => $nuevoId,
            "matricula" => $datos["matricula"] ?? "",
            "marca"     => $datos["marca"]     ?? "",
            "modelo"    => $datos["modelo"]    ?? "",
            "capacidad" => $datos["capacidad"] ?? null,
            "estado"    => $datos["estado"]    ?? "operativo",
        ];
    }
}