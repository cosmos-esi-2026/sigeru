<?php
// ============================================================================
//  SiGeRU 2026 - API de recoleccion
//  Archivo: config/database.php
//  Conexion PDO a MySQL. NO se usa en Entrega 1; lista para Entrega 2.
// ============================================================================

class Database
{
    private const HOST    = "db";
    private const PUERTO  = "3306";
    private const NOMBRE  = "sigeru";
    private const USUARIO = "sigeru";
    private const CLAVE   = "sigeru123";

    public static function conectar(): PDO
    {
        $dsn = "mysql:host=" . self::HOST .
               ";port=" . self::PUERTO .
               ";dbname=" . self::NOMBRE .
               ";charset=utf8mb4";

        $opciones = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ];

        return new PDO($dsn, self::USUARIO, self::CLAVE, $opciones);
    }
}