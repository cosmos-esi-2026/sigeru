<?php
// ============================================================================
//  SiGeRU 2026 - API de usuarios
//  Archivo: config/database.php
//  Que es: la conexion a la base de datos MySQL usando PDO.
//
//  IMPORTANTE (Entrega 1):
//   En esta entrega NO usamos la base de datos todavia: los modelos trabajan
//   con datos en memoria. Este archivo queda listo para la Entrega 2, donde
//   solo habra que llamar a Database::conectar() desde los modelos.
//
//  Los datos de conexion coinciden con el docker-compose.yml.
// ============================================================================

class Database
{
    // Datos de conexion (se pueden mover a variables de entorno mas adelante).
    private const HOST   = "db";       // nombre del servicio MySQL en Docker
    private const PUERTO = "3306";
    private const NOMBRE = "sigeru";
    private const USUARIO = "sigeru";
    private const CLAVE   = "sigeru123";

    // Devuelve una conexion PDO lista para usar.
    public static function conectar(): PDO
    {
        $dsn = "mysql:host=" . self::HOST .
               ";port=" . self::PUERTO .
               ";dbname=" . self::NOMBRE .
               ";charset=utf8mb4";

        // PDO lanza excepciones si algo falla (mas facil de depurar).
        $opciones = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ];

        return new PDO($dsn, self::USUARIO, self::CLAVE, $opciones);
    }
}