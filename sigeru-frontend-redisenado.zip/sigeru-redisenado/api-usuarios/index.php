<?php
// ============================================================================
//  SiGeRU 2026 - API de usuarios
//  Archivo: index.php  (router / punto de entrada)
//  Que hace: lee la URL y el metodo HTTP, y llama al metodo correcto del
//            controlador. Es el "recepcionista" de la API.
//
//  Endpoints de la Entrega 1:
//    GET  /usuarios          -> lista de usuarios
//    GET  /usuarios/{id}     -> un usuario
//    POST /usuarios          -> crear usuario
//    POST /login             -> iniciar sesion
//    POST /solicitudes       -> registrar solicitud (desde la landing)
// ============================================================================

require_once __DIR__ . "/core/Response.php";
require_once __DIR__ . "/controllers/UsuarioController.php";

// 1) Habilitamos CORS (permite que el frontend, en otro puerto, llame aca).
Response::cors();

// 2) Obtenemos el metodo HTTP (GET, POST, etc.).
$metodo = $_SERVER["REQUEST_METHOD"];

// 3) Obtenemos la ruta pedida, sin parametros de consulta (?algo=1).
//    Ejemplo: de "/usuarios/2?x=1" nos quedamos con "/usuarios/2".
$ruta = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
$ruta = rtrim($ruta, "/");            // quita la barra final si la hay
$partes = explode("/", trim($ruta, "/")); // ["usuarios", "2"]

$recurso = $partes[0] ?? "";          // "usuarios", "login", "solicitudes"
$id      = $partes[1] ?? null;        // "2" o null

$controlador = new UsuarioController();

// 4) Decidimos que hacer segun recurso + metodo (enrutamiento simple).
switch ($recurso) {

    case "usuarios":
        if ($metodo === "GET" && $id !== null) {
            $controlador->obtener((int) $id);     // GET /usuarios/{id}
        } elseif ($metodo === "GET") {
            $controlador->listar();               // GET /usuarios
        } elseif ($metodo === "POST") {
            $controlador->crear();                // POST /usuarios
        } else {
            Response::json(["ok" => false, "mensaje" => "Metodo no permitido"], 405);
        }
        break;

    case "login":
        if ($metodo === "POST") {
            $controlador->login();                // POST /login
        } else {
            Response::json(["ok" => false, "mensaje" => "Metodo no permitido"], 405);
        }
        break;

    case "solicitudes":
        if ($metodo === "POST") {
            $controlador->crearSolicitud();       // POST /solicitudes
        } else {
            Response::json(["ok" => false, "mensaje" => "Metodo no permitido"], 405);
        }
        break;

    case "":
        // Ruta raiz: mensaje de bienvenida para saber que la API responde.
        Response::json([
            "ok" => true,
            "mensaje" => "API de usuarios SiGeRU funcionando",
            "endpoints" => ["/usuarios", "/usuarios/{id}", "/login", "/solicitudes"]
        ]);
        break;

    default:
        Response::json(["ok" => false, "mensaje" => "Recurso no encontrado"], 404);
}