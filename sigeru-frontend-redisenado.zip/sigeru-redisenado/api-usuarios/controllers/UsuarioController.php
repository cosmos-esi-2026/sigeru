<?php
// ============================================================================
//  SiGeRU 2026 - API de usuarios
//  Archivo: controllers/UsuarioController.php  (la "C" de MVC)
//  Que es: el controlador. Recibe las peticiones, usa el modelo Usuario
//          y devuelve la respuesta en JSON usando la clase Response.
//
//  Aclaracion: el JSON es solo el FORMATO de respuesta de la API REST
//  (no es una base de datos). La persistencia real sera MySQL en Entrega 2.
// ============================================================================

require_once __DIR__ . "/../models/Usuario.php";
require_once __DIR__ . "/../core/Response.php";

class UsuarioController
{
    // GET /usuarios  -> lista todos los usuarios
    public function listar(): void
    {
        $usuarios = Usuario::listar();
        Response::json(["ok" => true, "datos" => $usuarios]);
    }

    // GET /usuarios/{id}  -> un usuario por id
    public function obtener(int $id): void
    {
        $usuario = Usuario::obtener($id);
        if ($usuario === null) {
            Response::json(["ok" => false, "mensaje" => "Usuario no encontrado"], 404);
        }
        Response::json(["ok" => true, "datos" => $usuario]);
    }

    // POST /usuarios  -> crea un usuario (en memoria, Entrega 1)
    public function crear(): void
    {
        $datos = Response::leerJson();

        // Validacion minima de campos obligatorios.
        if (empty($datos["nombre"]) || empty($datos["email"])) {
            Response::json(["ok" => false, "mensaje" => "Faltan datos: nombre y email"], 400);
        }

        $nuevo = Usuario::crear($datos);
        Response::json(["ok" => true, "mensaje" => "Usuario creado", "datos" => $nuevo], 201);
    }

    // POST /login  -> valida credenciales
    public function login(): void
    {
        $datos = Response::leerJson();
        $email = $datos["email"] ?? "";
        $clave = $datos["password"] ?? "";

        $usuario = Usuario::login($email, $clave);
        if ($usuario === null) {
            Response::json(["ok" => false, "mensaje" => "Email o contrasena incorrectos"], 401);
        }

        // En Entrega 1 devolvemos el usuario. En entregas futuras: un token.
        Response::json(["ok" => true, "mensaje" => "Login correcto", "datos" => $usuario]);
    }

    // POST /solicitudes  -> registra una solicitud de la landing
    public function crearSolicitud(): void
    {
        $datos = Response::leerJson();

        if (empty($datos["nombre"]) || empty($datos["email"])) {
            Response::json(["ok" => false, "mensaje" => "Faltan datos: nombre y email"], 400);
        }

        // Entrega 1: solo confirmamos la recepcion (sin guardar en BD).
        // Entrega 2: INSERT INTO solicitud_registro (...).
        Response::json([
            "ok" => true,
            "mensaje" => "Solicitud recibida",
            "datos" => [
                "nombre"   => $datos["nombre"],
                "email"    => $datos["email"],
                "estado"   => "pendiente",
            ]
        ], 201);
    }
}