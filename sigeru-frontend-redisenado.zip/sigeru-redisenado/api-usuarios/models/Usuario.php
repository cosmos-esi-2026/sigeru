<?php
// ============================================================================
//  SiGeRU 2026 - API de usuarios
//  Archivo: models/Usuario.php  (la "M" de MVC)
//  Que es: el modelo. Representa los datos de usuarios y solicitudes.
//
//  ENTREGA 1: los datos estan "quemados" en arrays dentro de la clase
//  (sin base de datos real). Cada metodo tiene un comentario indicando
//  como quedaria con MySQL en la Entrega 2.
// ============================================================================

class Usuario
{
    // --- Datos simulados de usuarios (en memoria) ---
    // En la Entrega 2 esto se reemplaza por consultas SQL a la tabla 'usuario'.
    private static array $usuarios = [
        [
            "id_usuario" => 1, "nombre" => "Ana", "apellido" => "Perez",
            "email" => "admin@sigeru.uy", "rol" => "Administrador", "estado" => "activo"
        ],
        [
            "id_usuario" => 2, "nombre" => "Luis", "apellido" => "Gomez",
            "email" => "cuadrilla@sigeru.uy", "rol" => "Cuadrilla", "estado" => "activo"
        ],
        [
            "id_usuario" => 3, "nombre" => "Marta", "apellido" => "Rodriguez",
            "email" => "vecino@sigeru.uy", "rol" => "Vecino", "estado" => "activo"
        ],
    ];

    // Devuelve todos los usuarios.
    // Entrega 2:  SELECT * FROM usuario;
    public static function listar(): array
    {
        return self::$usuarios;
    }

    // Devuelve un usuario por su id, o null si no existe.
    // Entrega 2:  SELECT * FROM usuario WHERE id_usuario = ?;
    public static function obtener(int $id): ?array
    {
        foreach (self::$usuarios as $u) {
            if ($u["id_usuario"] === $id) {
                return $u;
            }
        }
        return null;
    }

    // "Crea" un usuario (en memoria solo devolvemos el objeto con un id nuevo).
    // Entrega 2:  INSERT INTO usuario (...) VALUES (...);
    public static function crear(array $datos): array
    {
        $nuevoId = count(self::$usuarios) + 1;
        return [
            "id_usuario" => $nuevoId,
            "nombre"     => $datos["nombre"]   ?? "",
            "apellido"   => $datos["apellido"] ?? "",
            "email"      => $datos["email"]    ?? "",
            "rol"        => $datos["rol"]      ?? "Vecino",
            "estado"     => "activo",
        ];
    }

    // Login simulado: valida email y contrasena.
    // En Entrega 1 aceptamos la contrasena "123456" para los emails de prueba.
    // Entrega 2: buscar el usuario por email y verificar con password_verify().
    public static function login(string $email, string $clave): ?array
    {
        foreach (self::$usuarios as $u) {
            if ($u["email"] === $email && $clave === "123456") {
                return $u;
            }
        }
        return null;
    }
}