<?php
// ============================================================================
//  SiGeRU 2026 - API de usuarios
//  Archivo: core/Response.php
//  Que es: una clase auxiliar para responder siempre en formato JSON
//          y para habilitar CORS (permitir que el frontend llame a la API).
// ============================================================================

class Response
{
    // Activa los encabezados CORS (necesario porque el frontend y la API
    // estan en puertos distintos durante el desarrollo).
    public static function cors(): void
    {
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");

        // El navegador envia una peticion previa OPTIONS; respondemos vacio.
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
    }

    // Envia una respuesta JSON con un codigo de estado HTTP.
    // $datos: lo que se devuelve. $codigo: 200 = ok, 201 = creado, 404, etc.
    public static function json($datos, int $codigo = 200): void
    {
        http_response_code($codigo);
        header("Content-Type: application/json; charset=utf-8");
        echo json_encode($datos, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Lee el cuerpo JSON que envia el frontend (en POST/PUT) y lo convierte
    // en un array asociativo de PHP.
    public static function leerJson(): array
    {
        $crudo = file_get_contents("php://input");
        $datos = json_decode($crudo, true);
        return is_array($datos) ? $datos : [];
    }
}